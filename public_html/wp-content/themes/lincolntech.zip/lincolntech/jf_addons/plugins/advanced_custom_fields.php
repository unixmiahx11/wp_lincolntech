<?php
/**
 * Display all pages of any post type for a "Post Object" field with the name 'program'
 */
add_filter( 'acf/fields/post_object/query/name=program', 'jf_enable_all' );

function jf_enable_all($args) {
    $args['post_status'] = 'any';
    return $args;
}